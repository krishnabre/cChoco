﻿Configuration myChocoConfig
{
   Import-DscResource -Module cChoco
   
   
      LocalConfigurationManager
      {
          DebugMode = 'ForceModuleImport'
      }
      cChocoInstaller installChoco
      {
        InstallDir = "c:\choco"
      }
      cChocoPackageInstaller installDotNet
      {
        Name = "dotnet4.5"
        DependsOn = "[cChocoInstaller]installChoco"
      }
      
   
} 

myChocoConfig

Start-DscConfiguration -Path .\myChocoConfig -wait -Verbose -force